---
name: Feature request template
about: Plantilla guia para la elaboración de features en este proyecto.
title: ''
labels: Feature request
assignees: ''

---

## Nombre de la función / modulo
Nombre a asignar a la función/ modulo a implementar

## Ruta de la función / modulo
Ruta desde el menu de la aplicación para llamar a la función o forma en la que se ejecutara esta función/modulo 

## Material de apoyo
Código de apoyo, material de soporte o enlaces a la documentación sugerida.
